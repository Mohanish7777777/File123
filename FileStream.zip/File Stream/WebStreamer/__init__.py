# This file is a part of TG-FileStreamBot


import time
from .vars import Var
from WebStreamer.bot.clients import StreamBot

__version__ = 2.2
StartTime = time.time()
